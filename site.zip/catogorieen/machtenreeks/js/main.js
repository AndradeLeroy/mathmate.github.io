




function bereken(){

var x = parseFloat(document.getElementById("usr1").value);
var y = parseFloat(document.getElementById("usr2").value);
var z = Math.pow(x, y);
   
 document.getElementById("demo").innerHTML ="De uitkomst is: " + z;   
    
}








